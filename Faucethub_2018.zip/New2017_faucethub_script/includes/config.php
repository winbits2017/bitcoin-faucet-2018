<?php

$GLOBALS['config'] = array(
    'mysql' => array (
	    'host' => 'localhost',  
	    'db' => 'faucetscript',
	    'username' => 'root', 
	    'password' => '' 
	)
);